
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Message, StudyMode } from './types';
import { sendMessage } from './services/geminiService';
import { ChatBubble } from './components/ChatBubble';
import { Button } from './components/Button';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Hi there! I'm your StudyBuddy. Whether it's quantum physics or basic grammar, I'm here to explain it simply with plenty of examples. What are we learning today?",
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<StudyMode>(StudyMode.GENERAL);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const assistantId = (Date.now() + 1).toString();
    const initialAssistantMessage: Message = {
      id: assistantId,
      role: 'assistant',
      content: '',
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, initialAssistantMessage]);

    try {
      await sendMessage(input, mode, (chunkedText) => {
        setMessages(prev => prev.map(msg => 
          msg.id === assistantId ? { ...msg, content: chunkedText } : msg
        ));
      });
    } catch (error) {
      setMessages(prev => prev.map(msg => 
        msg.id === assistantId 
          ? { ...msg, content: "Oops! I ran into a bit of trouble connecting to my brain. Please try again." } 
          : msg
      ));
    } finally {
      setIsLoading(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    if (window.confirm("Are you sure you want to clear this study session?")) {
      setMessages([messages[0]]);
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden backdrop-blur-sm"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 w-72 bg-white border-r border-slate-200 transform transition-transform duration-300 z-50 lg:relative lg:translate-x-0 ${
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="flex flex-col h-full">
          <div className="p-6 border-b border-slate-100 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
              <i className="fa-solid fa-brain text-white text-xl"></i>
            </div>
            <div>
              <h1 className="font-bold text-slate-800 text-lg">StudyBuddy</h1>
              <p className="text-xs text-indigo-500 font-medium tracking-wide uppercase">AI Tutor</p>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            <div>
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest px-2 mb-2 block">
                Study Mode
              </label>
              <div className="space-y-1">
                {Object.values(StudyMode).map((m) => (
                  <button
                    key={m}
                    onClick={() => setMode(m)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      mode === m 
                        ? 'bg-indigo-50 text-indigo-700' 
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <i className={`fa-solid ${
                      m === StudyMode.GENERAL ? 'fa-message' :
                      m === StudyMode.SIMPLIFY ? 'fa-baby-carriage' :
                      m === StudyMode.EXAMPLES ? 'fa-lightbulb' : 'fa-list-check'
                    } w-5 text-center`}></i>
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 bg-amber-50 rounded-xl border border-amber-100">
              <h3 className="text-amber-800 font-semibold text-sm flex items-center gap-2 mb-1">
                <i className="fa-solid fa-circle-info"></i>
                Pro Tip
              </h3>
              <p className="text-amber-700 text-xs leading-relaxed">
                Ask me for a "Quick Quiz" on any topic to test your knowledge!
              </p>
            </div>
          </div>

          <div className="p-4 border-t border-slate-100 space-y-2">
            <Button 
              variant="secondary" 
              className="w-full text-sm" 
              onClick={clearChat}
            >
              <i className="fa-solid fa-trash-can mr-2"></i>
              Clear Session
            </Button>
            <p className="text-[10px] text-slate-400 text-center">Powered by Gemini AI</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-white shadow-2xl">
        {/* Header */}
        <header className="h-16 border-b border-slate-100 flex items-center justify-between px-4 lg:px-8 bg-white/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <button 
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
              onClick={() => setIsSidebarOpen(true)}
            >
              <i className="fa-solid fa-bars-staggered"></i>
            </button>
            <div>
              <h2 className="font-semibold text-slate-800 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                {mode}
              </h2>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 text-xs font-medium text-slate-500">
            <span className="px-2 py-1 bg-slate-100 rounded">Simple Language</span>
            <span className="px-2 py-1 bg-slate-100 rounded">Practical Examples</span>
          </div>
        </header>

        {/* Chat Area */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-4 lg:p-8 space-y-4 scroll-smooth"
        >
          <div className="max-w-4xl mx-auto">
            {messages.map((msg) => (
              <ChatBubble key={msg.id} message={msg} />
            ))}
            {isLoading && messages[messages.length-1].content === '' && (
              <div className="flex justify-start items-center gap-2 text-slate-400 text-sm animate-pulse ml-12">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce"></span>
                </div>
                Thinking...
              </div>
            )}
          </div>
        </div>

        {/* Input Area */}
        <div className="p-4 lg:p-6 bg-white border-t border-slate-100">
          <div className="max-w-4xl mx-auto relative">
            <div className="relative group">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything... (e.g., 'What is photosynthesis?')"
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 pr-14 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none shadow-sm text-slate-800 placeholder:text-slate-400 min-h-[60px] max-h-[200px]"
                rows={1}
                style={{ height: 'auto' }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = `${Math.min(target.scrollHeight, 200)}px`;
                }}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className={`absolute right-2 bottom-2 p-3 rounded-xl transition-all ${
                  input.trim() && !isLoading
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100 hover:scale-105 active:scale-95'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                {isLoading ? (
                  <i className="fa-solid fa-spinner fa-spin"></i>
                ) : (
                  <i className="fa-solid fa-paper-plane"></i>
                )}
              </button>
            </div>
            <p className="mt-2 text-[10px] text-slate-400 text-center">
              Hit Enter to send. Use Shift+Enter for new lines.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
