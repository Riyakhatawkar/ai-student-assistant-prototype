
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { StudyMode } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const getSystemInstruction = (mode: StudyMode): string => {
  const base = "You are an AI assistant for students. Explain concepts in simple language. Give short answers with examples.";
  
  switch (mode) {
    case StudyMode.SIMPLIFY:
      return `${base} Specifically, explain things as if the student is 10 years old. Avoid jargon or define it immediately.`;
    case StudyMode.EXAMPLES:
      return `${base} Focus heavily on providing real-world, relatable examples for every concept mentioned.`;
    case StudyMode.SUMMARIZE:
      return `${base} Be extremely concise. Use bullet points and bold text to highlight key takeaways.`;
    default:
      return base;
  }
};

export const sendMessage = async (
  prompt: string, 
  mode: StudyMode,
  onChunk: (text: string) => void
) => {
  try {
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: getSystemInstruction(mode),
        temperature: 0.7,
        topP: 0.95,
      },
    });

    let fullText = "";
    for await (const chunk of responseStream) {
      const text = (chunk as GenerateContentResponse).text;
      if (text) {
        fullText += text;
        onChunk(fullText);
      }
    }
    return fullText;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
