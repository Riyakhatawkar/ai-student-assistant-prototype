
export type Role = 'user' | 'assistant';

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
}

export enum StudyMode {
  GENERAL = 'General Help',
  SIMPLIFY = 'Simplify (ELI5)',
  EXAMPLES = 'Give Examples',
  SUMMARIZE = 'Quick Summary'
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  mode: StudyMode;
}
